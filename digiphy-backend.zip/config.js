module.exports = {
    //   mysqlHost: "localhost",
    mysqlHost: "espsofttech.in",
    user: "esp",
    password: "Espsoft123#",
    database: "digiphynft",


    mysqlPort: 3306,

    JWT_SECRET_KEY: '6dqw7dydyw7ewyuw',
    SESSION_EXPIRES_IN: '1h', // Session will expire after 1 day of creation
    imageUrl: 'https://infinity8.mypinata.cloud/ipfs/',

    // OLD KEY BEFORE UPDATE 20210617
    // contractOwnerAddress : '0xcf601e63906c587245b614baa8ad35a073cdee01', //live
    // contractOwnerPrivateKey : '0xbbb184aef7ee8e86998089c376069a8bb915bef5e6533645ec728deb44944b86', 

    // contractOwnerAddress : '0xB45F05cBC7614f50f31409Bec10e06cdFa0Bc168', //live
    // contractOwnerPrivateKey : '0x085db8f0ba24dbfb49ae9967533db2efc028a8812309f380c34fee96794261b1', 

    //  stripe_key : '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', //live
    //  contractAddress : '0xe77453441415a1e211e562fe5540110f8fcaad06', //live
    //  blockchainApiUrl :'https://infinity8.io:8001/api/erc1155/mainnet/', //mainnet
    //  ethTransferApiUrl : 'https://infinity8.io:8001/api/eth/mainnet/transfer',
    //  contractOwnerAddress : '0x289521dF06DcF689c6ec644Ee7A3e38e1493AB5c', //live
    //  apiKey : '0x8161a9bfd7e09c2e4c8a5adc16aa3c878bdd487e556621004eda79296bd4c04e', 
    //  netCentsAuthorization : 'Basic SVROSXBvTVB6SGpRRmcyYnlHeHliczNCc2NNdVZQUkI6NW1mdjk4aWlaQnhwSFFQRHdHc2FmOE9MUDdqbVZFaGs1UmNLQS1NVmFyWGZjS3dBT3pSbXRiTFo=',
    //  netCentshostedPaymentId: "3288",
    //  blockchainNetwork:'mainnet',
    //  mailUrl:'https://infinity8.io/',
    //  explorerLink: 'https://espsofttech.in/infinity8-explorer/',
    // circleApiUrl : 'https://api-sandbox.circle.com/v1/',
    //circleApiKey : 'QVBJX0tFWTpjNDMyMTM0MzcxNzk1YWRlYjQzN2FmYjc2MDZiNzFjZjoxMTQyN2JlOTVjMjg1NzZlYzE4Yzg4ZjQ1NDgwNDA3OA=='
    // circleApiKeyId : 'key1'


    walletApiUrl: "https://espsofttech.in:8001/api/erc1155/mainnet/createWallet",
    blockchainApiUrl: 'https://espsofttech.in:8001/api/erc1155/matictest/', //testnet
    ethTransferApiUrl: 'https://espsofttech.in:8001/api/matic/testnet/transfer',
    contractAddress: '0xa133d14922c9ea05accc357526cf823f75401997',// test
    contractOwnerAddress: '0x22ad707a2572f2eb573586cB73dA75E0c52e651f', //testnet
    blockchainNetwork: 'testnet',
    mailUrl: 'https://espsofttech.in/digiphynft/'



}

